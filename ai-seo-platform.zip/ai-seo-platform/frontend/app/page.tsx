import Link from "next/link";

const FEATURES = [
  { name: "Topic & Entity Extraction", desc: "Surface topical clusters and named entities across your content." },
  { name: "Search Intent Classification", desc: "Informational, navigational, transactional, or commercial." },
  { name: "Content Gap Detection", desc: "Find sub-topics competitors cover that you don't." },
  { name: "Internal Link Suggestions", desc: "Contextual links based on semantic similarity." },
  { name: "Schema.org Suggestions", desc: "Structured-data recommendations per page." },
  { name: "Content Decay Monitoring", desc: "Flag pages losing traffic or rankings over time." },
];

export default function Home() {
  return (
    <main className="max-w-5xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-semibold tracking-tight">
        AI Content Quality & Semantic SEO Platform
      </h1>
      <p className="mt-3 text-slate-600 max-w-2xl">
        Content intelligence for topic coverage, entities, search intent, internal
        links, structured data, and content freshness — with an editorial
        workflow for human review.
      </p>

      <Link
        href="/dashboard"
        className="inline-block mt-8 px-5 py-2.5 rounded-md bg-slate-900 text-white text-sm font-medium hover:bg-slate-700 transition"
      >
        Open Dashboard
      </Link>

      <div className="grid sm:grid-cols-2 gap-4 mt-12">
        {FEATURES.map((f) => (
          <div key={f.name} className="rounded-lg border border-slate-200 bg-white p-5">
            <h2 className="font-medium">{f.name}</h2>
            <p className="text-sm text-slate-500 mt-1">{f.desc}</p>
          </div>
        ))}
      </div>

      <footer className="mt-16 text-xs text-slate-400">
        Copyright (c) 2026 Bibas Gautam. Licensed under the MIT License.
      </footer>
    </main>
  );
}
