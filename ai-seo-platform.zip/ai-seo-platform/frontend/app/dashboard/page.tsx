"use client";

import { useState } from "react";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export default function Dashboard() {
  const [text, setText] = useState("");
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleExtract() {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch(`${API_URL}/api/v1/topics/extract`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      setResult(await res.json());
    } catch (e: any) {
      setError(e.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="text-2xl font-semibold">Topic & Entity Extraction</h1>
      <p className="text-sm text-slate-500 mt-1">
        Paste content below and extract topics + entities via the backend API.
      </p>

      <textarea
        className="mt-6 w-full h-48 rounded-md border border-slate-300 p-3 text-sm"
        placeholder="Paste your article or page content here..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />

      <button
        onClick={handleExtract}
        disabled={loading || !text.trim()}
        className="mt-4 px-5 py-2.5 rounded-md bg-slate-900 text-white text-sm font-medium disabled:opacity-40"
      >
        {loading ? "Analyzing..." : "Extract Topics & Entities"}
      </button>

      {error && <p className="mt-4 text-sm text-red-600">{error}</p>}

      {result && (
        <div className="mt-8 rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="font-medium mb-2">Topics</h2>
          <ul className="list-disc list-inside text-sm text-slate-700">
            {result.topics?.map((t: string) => (
              <li key={t}>{t}</li>
            ))}
          </ul>

          <h2 className="font-medium mt-4 mb-2">Entities</h2>
          <ul className="text-sm text-slate-700 space-y-1">
            {result.entities?.map((e: any) => (
              <li key={e.name}>
                <span className="font-medium">{e.name}</span> — {e.type} (salience {e.salience})
              </li>
            ))}
          </ul>
        </div>
      )}
    </main>
  );
}
