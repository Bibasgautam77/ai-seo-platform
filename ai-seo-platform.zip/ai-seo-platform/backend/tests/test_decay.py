"""
Copyright (c) 2026 Bibas Gautam
"""
from app.services.decay_monitor import score_decay
from app.models.schemas import DecayStatus


def test_decaying_when_traffic_and_rank_drop():
    assert score_decay(traffic_change_pct=-30, ranking_change=-5, days_since_update=100) == DecayStatus.decaying


def test_watch_when_only_stale():
    assert score_decay(traffic_change_pct=2, ranking_change=1, days_since_update=200) == DecayStatus.watch


def test_healthy_when_stable():
    assert score_decay(traffic_change_pct=5, ranking_change=2, days_since_update=30) == DecayStatus.healthy
