"""
Application configuration.

Copyright (c) 2026 Bibas Gautam
Licensed under the MIT License.
"""
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    ENVIRONMENT: str = "development"
    SECRET_KEY: str = "change_me"

    DATABASE_URL: str = "postgresql+asyncpg://seo_admin:change_me@localhost:5432/seo_platform"

    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"

    ELASTICSEARCH_URL: str = "http://localhost:9200"

    VECTOR_DB_URL: str = "http://localhost:6333"
    VECTOR_DB_COLLECTION: str = "content_embeddings"

    LLM_PROVIDER: str = "anthropic"
    LLM_API_KEY: str = ""
    LLM_MODEL: str = "claude-sonnet-4-6"
    EMBEDDING_MODEL: str = "text-embedding-3-small"

    BACKEND_CORS_ORIGINS: List[str] = ["http://localhost:3000"]

    DECAY_CHECK_INTERVAL_HOURS: int = 24
    DECAY_TRAFFIC_DROP_THRESHOLD_PCT: int = 20

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
