"""
AI Content Quality & Semantic SEO Platform — backend entrypoint.

Copyright (c) 2026 Bibas Gautam
Licensed under the MIT License. See LICENSE at the repo root.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import decay, gaps, intent, links, review, schema, topics
from app.core.config import settings

app = FastAPI(
    title="AI Content Quality & Semantic SEO Platform",
    description="Topic/entity extraction, intent classification, content gaps, "
    "internal links, schema suggestions, decay monitoring and editorial workflow.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(topics.router)
app.include_router(intent.router)
app.include_router(gaps.router)
app.include_router(links.router)
app.include_router(schema.router)
app.include_router(decay.router)
app.include_router(review.router)


@app.get("/health")
async def health():
    return {"status": "ok", "environment": settings.ENVIRONMENT}


@app.get("/")
async def root():
    return {
        "name": "AI Content Quality & Semantic SEO Platform",
        "copyright": "Copyright (c) 2026 Bibas Gautam",
        "docs": "/docs",
    }
