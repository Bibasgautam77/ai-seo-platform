"""
Copyright (c) 2026 Bibas Gautam
"""
from fastapi import APIRouter, HTTPException

from app.models.schemas import LinkSuggestionRequest, LinkSuggestionResponse
from app.services.link_suggester import suggest_internal_links

router = APIRouter(prefix="/api/v1/links", tags=["links"])


@router.post("/suggest", response_model=LinkSuggestionResponse)
async def suggest(payload: LinkSuggestionRequest):
    # In production, fetch the source content's text by payload.content_id
    # from Postgres/Elasticsearch before embedding it.
    source_text = f"content:{payload.content_id}"
    try:
        return await suggest_internal_links(payload.content_id, source_text, payload.max_suggestions)
    except Exception as exc:  # pragma: no cover
        raise HTTPException(status_code=502, detail=f"Vector DB lookup failed: {exc}")
