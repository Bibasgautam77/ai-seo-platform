"""
Copyright (c) 2026 Bibas Gautam
"""
from fastapi import APIRouter

from app.models.schemas import SchemaSuggestionRequest, SchemaSuggestionResponse
from app.services.schema_suggester import suggest_schema

router = APIRouter(prefix="/api/v1/schema", tags=["schema"])


@router.post("/suggest", response_model=SchemaSuggestionResponse)
async def suggest(payload: SchemaSuggestionRequest):
    return await suggest_schema(payload.text, payload.content_type_hint)
