"""
Copyright (c) 2026 Bibas Gautam
"""
from fastapi import APIRouter

from app.models.schemas import IntentClassificationRequest, IntentClassificationResponse
from app.services.intent_classifier import classify_intent

router = APIRouter(prefix="/api/v1/intent", tags=["intent"])


@router.post("/classify", response_model=IntentClassificationResponse)
async def classify(payload: IntentClassificationRequest):
    return await classify_intent(payload.query_or_title, payload.body_snippet)
