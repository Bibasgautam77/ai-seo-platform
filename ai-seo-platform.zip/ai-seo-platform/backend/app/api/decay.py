"""
Copyright (c) 2026 Bibas Gautam
"""
from datetime import datetime, timedelta

from fastapi import APIRouter

from app.models.schemas import DecayReportResponse
from app.services.decay_monitor import build_decay_report

router = APIRouter(prefix="/api/v1/decay", tags=["decay"])


@router.get("/report", response_model=DecayReportResponse)
async def report():
    # In production, pull real metrics from your analytics/search-console
    # store. Sample data shown here so the endpoint is runnable out of the box.
    sample_metrics = [
        {
            "content_id": "post-123",
            "title": "How to Structure a Content Calendar",
            "traffic_change_pct": -34.5,
            "ranking_change": -6,
            "last_updated": datetime.utcnow() - timedelta(days=210),
        },
        {
            "content_id": "post-456",
            "title": "Semantic SEO Fundamentals",
            "traffic_change_pct": 4.2,
            "ranking_change": 1,
            "last_updated": datetime.utcnow() - timedelta(days=20),
        },
    ]
    return await build_decay_report(sample_metrics)
