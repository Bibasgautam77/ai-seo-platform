"""
Copyright (c) 2026 Bibas Gautam
"""
from fastapi import APIRouter

from app.models.schemas import ContentGapRequest, ContentGapResponse
from app.services.gap_analysis import analyze_gaps

router = APIRouter(prefix="/api/v1/gaps", tags=["gaps"])


@router.post("/analyze", response_model=ContentGapResponse)
async def analyze(payload: ContentGapRequest):
    # In production, our_topics / competitor_topics would be pulled from
    # Elasticsearch/vector DB using payload.our_content_ids and
    # payload.competitor_urls. Wire that lookup in here.
    our_topics: list[str] = []
    competitor_topics: list[str] = []
    return await analyze_gaps(payload.seed_topic, our_topics, competitor_topics)
