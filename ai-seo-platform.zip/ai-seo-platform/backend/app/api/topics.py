"""
Copyright (c) 2026 Bibas Gautam
"""
from fastapi import APIRouter

from app.models.schemas import TopicExtractionRequest, TopicExtractionResponse
from app.services.extraction import extract_topics_and_entities

router = APIRouter(prefix="/api/v1/topics", tags=["topics"])


@router.post("/extract", response_model=TopicExtractionResponse)
async def extract_topics(payload: TopicExtractionRequest):
    return await extract_topics_and_entities(payload.text)
