"""
Editorial workflow / human review endpoints.

In-memory store for scaffold purposes — swap for a Postgres-backed table
(see backend/app/models for where to add the ORM model) in production.

Copyright (c) 2026 Bibas Gautam
"""
from fastapi import APIRouter, HTTPException

from app.models.schemas import ReviewItem, ReviewState, ReviewTransitionRequest

router = APIRouter(prefix="/api/v1/review", tags=["review"])

_ALLOWED_TRANSITIONS = {
    ReviewState.draft: {ReviewState.in_review},
    ReviewState.in_review: {ReviewState.approved, ReviewState.draft},
    ReviewState.approved: {ReviewState.published, ReviewState.in_review},
    ReviewState.published: set(),
}

_store: dict[str, ReviewItem] = {}


@router.get("/{content_id}", response_model=ReviewItem)
async def get_review_item(content_id: str):
    item = _store.get(content_id)
    if not item:
        item = ReviewItem(content_id=content_id, state=ReviewState.draft)
        _store[content_id] = item
    return item


@router.post("/transition", response_model=ReviewItem)
async def transition(payload: ReviewTransitionRequest):
    item = _store.get(payload.content_id) or ReviewItem(
        content_id=payload.content_id, state=ReviewState.draft
    )

    allowed = _ALLOWED_TRANSITIONS.get(item.state, set())
    if payload.new_state not in allowed:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot move from '{item.state}' to '{payload.new_state}'",
        )

    item.state = payload.new_state
    if payload.comment:
        item.comments.append(payload.comment)

    _store[payload.content_id] = item
    return item
