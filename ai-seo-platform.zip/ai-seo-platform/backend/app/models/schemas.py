"""
Pydantic request/response models shared across API routes.

Copyright (c) 2026 Bibas Gautam
"""
from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


# --- Topic / Entity extraction ---

class TopicExtractionRequest(BaseModel):
    content_id: Optional[str] = None
    text: str = Field(..., min_length=1)


class Entity(BaseModel):
    name: str
    type: str
    salience: float


class TopicExtractionResponse(BaseModel):
    topics: List[str]
    entities: List[Entity]


# --- Search intent ---

class IntentType(str, Enum):
    informational = "informational"
    navigational = "navigational"
    transactional = "transactional"
    commercial = "commercial"


class IntentClassificationRequest(BaseModel):
    query_or_title: str
    body_snippet: Optional[str] = None


class IntentClassificationResponse(BaseModel):
    intent: IntentType
    confidence: float


# --- Content gaps ---

class ContentGapRequest(BaseModel):
    our_content_ids: List[str]
    competitor_urls: List[str] = []
    seed_topic: str


class ContentGap(BaseModel):
    topic: str
    covered_by_us: bool
    covered_by_competitors: int
    priority_score: float


class ContentGapResponse(BaseModel):
    gaps: List[ContentGap]


# --- Internal link suggestions ---

class LinkSuggestionRequest(BaseModel):
    content_id: str
    max_suggestions: int = 5


class LinkSuggestion(BaseModel):
    target_content_id: str
    target_title: str
    anchor_text_suggestion: str
    similarity_score: float


class LinkSuggestionResponse(BaseModel):
    suggestions: List[LinkSuggestion]


# --- Schema.org suggestions ---

class SchemaSuggestionRequest(BaseModel):
    content_id: str
    text: str
    content_type_hint: Optional[str] = None


class SchemaSuggestionResponse(BaseModel):
    recommended_types: List[str]
    json_ld: dict


# --- Content decay ---

class DecayStatus(str, Enum):
    healthy = "healthy"
    watch = "watch"
    decaying = "decaying"


class DecayReportItem(BaseModel):
    content_id: str
    title: str
    traffic_change_pct: float
    ranking_change: int
    last_updated: datetime
    status: DecayStatus


class DecayReportResponse(BaseModel):
    items: List[DecayReportItem]


# --- Editorial workflow ---

class ReviewState(str, Enum):
    draft = "draft"
    in_review = "in_review"
    approved = "approved"
    published = "published"


class ReviewItem(BaseModel):
    content_id: str
    state: ReviewState
    assignee: Optional[str] = None
    comments: List[str] = []


class ReviewTransitionRequest(BaseModel):
    content_id: str
    new_state: ReviewState
    comment: Optional[str] = None
