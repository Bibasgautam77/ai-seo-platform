"""
Topic and entity extraction.

Copyright (c) 2026 Bibas Gautam
"""
from app.models.schemas import Entity, TopicExtractionResponse
from app.services.llm_client import complete_json

SYSTEM_PROMPT = """You are a semantic SEO analyst. Given a piece of web content,
extract:
1. "topics": 3-8 concise topical clusters the content covers (short noun phrases).
2. "entities": named entities mentioned, each with a "name", a "type"
   (Person, Organization, Product, Location, Concept, Other), and a
   "salience" score from 0.0 to 1.0 indicating how central it is to the content.

Return ONLY valid JSON, no preamble, in the shape:
{"topics": ["..."], "entities": [{"name": "...", "type": "...", "salience": 0.0}]}
"""


async def extract_topics_and_entities(text: str) -> TopicExtractionResponse:
    result = await complete_json(SYSTEM_PROMPT, text[:8000])
    entities = [Entity(**e) for e in result.get("entities", [])]
    return TopicExtractionResponse(topics=result.get("topics", []), entities=entities)
