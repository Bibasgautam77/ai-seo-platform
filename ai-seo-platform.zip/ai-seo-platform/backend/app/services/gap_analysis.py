"""
Content gap analysis: compares our topic coverage against a competitor set
or SERP corpus indexed in Elasticsearch, and scores missing topics by
opportunity.

Copyright (c) 2026 Bibas Gautam
"""
from typing import List

from app.models.schemas import ContentGap, ContentGapResponse
from app.services.llm_client import complete_json

SYSTEM_PROMPT = """You are an SEO content strategist. Given a seed topic and a
list of sub-topics already covered by our own content versus sub-topics found
in competitor content, identify content gaps: sub-topics competitors cover
that we do not, or under-cover. For each gap, estimate a priority_score from
0.0 to 1.0 based on how central it is to the seed topic and how many
competitors cover it.

Return ONLY valid JSON:
{"gaps": [{"topic": "...", "covered_by_us": false, "covered_by_competitors": 0, "priority_score": 0.0}]}
"""


async def analyze_gaps(seed_topic: str, our_topics: List[str], competitor_topics: List[str]) -> ContentGapResponse:
    prompt = (
        f"Seed topic: {seed_topic}\n"
        f"Our covered sub-topics: {our_topics}\n"
        f"Competitor covered sub-topics: {competitor_topics}\n"
    )
    result = await complete_json(SYSTEM_PROMPT, prompt)
    gaps = [ContentGap(**g) for g in result.get("gaps", [])]
    gaps.sort(key=lambda g: g.priority_score, reverse=True)
    return ContentGapResponse(gaps=gaps)
