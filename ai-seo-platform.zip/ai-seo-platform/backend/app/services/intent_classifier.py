"""
Search intent classification.

Copyright (c) 2026 Bibas Gautam
"""
from app.models.schemas import IntentClassificationResponse, IntentType
from app.services.llm_client import complete_json

SYSTEM_PROMPT = """You are a search-intent classifier for SEO. Classify the
primary search intent behind the given query or page title (optionally with
a body snippet for context) into exactly one of:
informational, navigational, transactional, commercial.

Return ONLY valid JSON: {"intent": "...", "confidence": 0.0}
"""


async def classify_intent(query_or_title: str, body_snippet: str | None) -> IntentClassificationResponse:
    prompt = query_or_title
    if body_snippet:
        prompt += f"\n\nBody excerpt:\n{body_snippet[:1000]}"

    result = await complete_json(SYSTEM_PROMPT, prompt)
    return IntentClassificationResponse(
        intent=IntentType(result.get("intent", "informational")),
        confidence=float(result.get("confidence", 0.5)),
    )
