"""
Schema.org structured-data suggestions.

Copyright (c) 2026 Bibas Gautam
"""
from app.models.schemas import SchemaSuggestionResponse
from app.services.llm_client import complete_json

SYSTEM_PROMPT = """You are a structured-data (schema.org) expert. Given page
content (and an optional content-type hint like "blog post", "product page",
"faq", "recipe", "how-to"), recommend the most relevant schema.org types and
produce a best-effort JSON-LD block populated with whatever fields can be
inferred from the text (leave placeholders like "TODO" for fields that need
manual input, such as exact prices or dates).

Return ONLY valid JSON:
{"recommended_types": ["Article", "FAQPage"], "json_ld": { "@context": "https://schema.org", ... }}
"""


async def suggest_schema(text: str, content_type_hint: str | None) -> SchemaSuggestionResponse:
    prompt = text[:6000]
    if content_type_hint:
        prompt = f"Content type hint: {content_type_hint}\n\n{prompt}"

    result = await complete_json(SYSTEM_PROMPT, prompt)
    return SchemaSuggestionResponse(
        recommended_types=result.get("recommended_types", []),
        json_ld=result.get("json_ld", {}),
    )
