"""
Content decay monitoring: flags pages whose organic traffic or rankings
have dropped meaningfully since last update, so editorial can prioritize
refreshes. Runs both on-demand (via the API) and on a daily Celery beat
schedule.

Copyright (c) 2026 Bibas Gautam
"""
from datetime import datetime, timedelta
from typing import List

from app.core.config import settings
from app.models.schemas import DecayReportItem, DecayReportResponse, DecayStatus


def score_decay(traffic_change_pct: float, ranking_change: int, days_since_update: int) -> DecayStatus:
    """
    Simple, explainable decay scoring:
      - decaying: traffic dropped past threshold AND rankings worsened
      - watch: traffic dropped past threshold OR content is stale (>180 days)
      - healthy: otherwise
    """
    threshold = settings.DECAY_TRAFFIC_DROP_THRESHOLD_PCT
    traffic_dropped = traffic_change_pct <= -threshold
    rankings_worsened = ranking_change < 0

    if traffic_dropped and rankings_worsened:
        return DecayStatus.decaying
    if traffic_dropped or days_since_update > 180:
        return DecayStatus.watch
    return DecayStatus.healthy


async def build_decay_report(raw_metrics: List[dict]) -> DecayReportResponse:
    """
    raw_metrics: list of dicts pulled from analytics/search-console storage, e.g.:
      {"content_id": "...", "title": "...", "traffic_change_pct": -35.2,
       "ranking_change": -4, "last_updated": datetime(...)}
    """
    items = []
    now = datetime.utcnow()
    for m in raw_metrics:
        days_since_update = (now - m["last_updated"]).days
        status = score_decay(m["traffic_change_pct"], m["ranking_change"], days_since_update)
        items.append(
            DecayReportItem(
                content_id=m["content_id"],
                title=m["title"],
                traffic_change_pct=m["traffic_change_pct"],
                ranking_change=m["ranking_change"],
                last_updated=m["last_updated"],
                status=status,
            )
        )
    items.sort(key=lambda i: i.traffic_change_pct)
    return DecayReportResponse(items=items)


# --- Celery periodic task ---
from app.worker import celery_app


@celery_app.task(name="app.services.decay_monitor.run_decay_scan")
def run_decay_scan():
    """
    Placeholder for the production job: pull latest analytics + search
    console data, recompute decay status for every indexed content_id,
    persist results, and enqueue notifications for anything newly
    flagged as 'decaying'.
    """
    return {"status": "ok", "scanned_at": datetime.utcnow().isoformat()}
