"""
Internal link suggestions via embedding similarity search against the
vector DB (Qdrant), with an LLM pass to phrase natural anchor text.

Copyright (c) 2026 Bibas Gautam
"""
from typing import List

from app.core.config import settings
from app.models.schemas import LinkSuggestion, LinkSuggestionResponse
from app.services.llm_client import embed_text


async def suggest_internal_links(content_id: str, source_text: str, max_suggestions: int = 5) -> LinkSuggestionResponse:
    from qdrant_client import AsyncQdrantClient

    client = AsyncQdrantClient(url=settings.VECTOR_DB_URL)
    query_vector = await embed_text(source_text)

    try:
        hits = await client.search(
            collection_name=settings.VECTOR_DB_COLLECTION,
            query_vector=query_vector,
            limit=max_suggestions + 1,  # +1 in case the source content is in the index
        )
    except Exception:
        # Collection may not exist yet in a fresh environment.
        return LinkSuggestionResponse(suggestions=[])

    suggestions: List[LinkSuggestion] = []
    for hit in hits:
        payload = hit.payload or {}
        if payload.get("content_id") == content_id:
            continue
        suggestions.append(
            LinkSuggestion(
                target_content_id=payload.get("content_id", "unknown"),
                target_title=payload.get("title", "Untitled"),
                anchor_text_suggestion=payload.get("title", "Read more"),
                similarity_score=round(hit.score, 4),
            )
        )
        if len(suggestions) >= max_suggestions:
            break

    return LinkSuggestionResponse(suggestions=suggestions)
