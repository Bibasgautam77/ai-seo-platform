"""
Thin wrapper around the configured LLM provider so services don't need to
know whether they're talking to Anthropic or OpenAI.

Copyright (c) 2026 Bibas Gautam
"""
import json
from typing import Any, Dict

from app.core.config import settings


async def complete_json(system_prompt: str, user_prompt: str) -> Dict[str, Any]:
    """
    Calls the configured LLM with instructions to return ONLY JSON, and
    parses the result. Raises ValueError if parsing fails.
    """
    if settings.LLM_PROVIDER == "anthropic":
        raw = await _call_anthropic(system_prompt, user_prompt)
    elif settings.LLM_PROVIDER == "openai":
        raw = await _call_openai(system_prompt, user_prompt)
    else:
        raise ValueError(f"Unsupported LLM_PROVIDER: {settings.LLM_PROVIDER}")

    cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    return json.loads(cleaned)


async def _call_anthropic(system_prompt: str, user_prompt: str) -> str:
    import anthropic

    client = anthropic.AsyncAnthropic(api_key=settings.LLM_API_KEY)
    resp = await client.messages.create(
        model=settings.LLM_MODEL,
        max_tokens=1500,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    )
    return "".join(block.text for block in resp.content if block.type == "text")


async def _call_openai(system_prompt: str, user_prompt: str) -> str:
    from openai import AsyncOpenAI

    client = AsyncOpenAI(api_key=settings.LLM_API_KEY)
    resp = await client.chat.completions.create(
        model=settings.LLM_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    )
    return resp.choices[0].message.content or ""


async def embed_text(text: str) -> list[float]:
    """Returns an embedding vector for the given text via the configured provider."""
    if settings.LLM_PROVIDER == "openai":
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=settings.LLM_API_KEY)
        resp = await client.embeddings.create(model=settings.EMBEDDING_MODEL, input=text)
        return resp.data[0].embedding

    # Fallback: simple deterministic hash-based pseudo-embedding for local dev
    # without an embeddings-capable provider configured. Swap this out for a
    # real embedding model (e.g. voyage-3, text-embedding-3-small) in production.
    import hashlib

    h = hashlib.sha256(text.encode()).digest()
    return [b / 255.0 for b in h] * 6  # 256-dim pseudo-vector
