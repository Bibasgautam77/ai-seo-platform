"""
Celery worker + beat schedule.

Copyright (c) 2026 Bibas Gautam
"""
from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

celery_app = Celery(
    "seo_platform",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["app.services.decay_monitor"],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
)

celery_app.conf.beat_schedule = {
    "run-decay-scan-daily": {
        "task": "app.services.decay_monitor.run_decay_scan",
        "schedule": crontab(hour=3, minute=0),
    },
}
